package com.im;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class FirstTest {

    private First first=new First();

    @Test
    public void should_replaceSubString_When_String_is_NotEmpty () {

        //given
        String mainString="hello world";
        String subString="world";
        String replacementString="earth";
        String expected = "hello earth";

        //when
        String actual = first.replaceSubString(mainString,subString,replacementString);

        //then
        assertEquals(expected, actual, "String Match");

    }

    @Test
    public void should_ThrowNullPointerException_When_StringIsEmpty() {

        //given
        String mainString="hi";
        String subString=null;
        String replacementString="hello";
        String expected = null;

        //when
        String actual = first.replaceSubString(mainString,subString,replacementString);

        //then
        assertNull(expected, actual);
    }

    @Test
    public void should_mainString_not_contain_subString(){
        //given
        String mainString="hello world";
        String subString="hi";
        String replacementString="earth";
        String expected = "hello earth";

        //when
        String actual = first.replaceSubString(mainString,subString,replacementString);

        //then
        assertNotEquals(expected, actual, "Main String not contains substring");

    }

    @Test
    void shouldReturnOddElementOnly_When_OddElementExist_AfterFilterEvenElement() {
        //given
        List<Integer> list = new ArrayList<>();
        for (int i = 1; i < 6; i++) {
            list.add(i);
        }
        List<Integer> expectedlist = new ArrayList<>();
        expectedlist.add(1);
        expectedlist.add(3);
        expectedlist.add(5);

        //when
        List calculatelist = first.filterEvenElements(list);

        //then
        assertEquals(expectedlist, calculatelist);

    }

    @Test
    void should_ReturnAverageValue_When_ListContainsElement() {

        //given
        List<BigDecimal> list = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            list.add(new BigDecimal(1212121));
            list.add(new BigDecimal(1212121));
            list.add(new BigDecimal(1212121));
            list.add(new BigDecimal(1212121));
        }
        BigDecimal expectedaverage = new BigDecimal(1212121);

        //when
        BigDecimal calculateaverage = first.calculateAverage(list);

        //then
        assertEquals(expectedaverage, calculateaverage);
    }

    @Test
    void should_ReturnTrue_When_StringIsPalindrome() {
        //given
        String originalInput = "naman";

        //when
        boolean palindromeCheck = first.isPallindrome(originalInput);

        //then
        assertTrue(palindromeCheck);
    }

    @Test
    void should_ReturnFalse_When_StringIsPalindrome() {
        //given
        String originalInput = "nirbhay";

        //when
        boolean palindromeCheck = first.isPallindrome(originalInput);

        //then
        assertFalse(palindromeCheck);
    }





}