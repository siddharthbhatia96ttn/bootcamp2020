package healthycoderapp;

class DietPlannerTest {

}